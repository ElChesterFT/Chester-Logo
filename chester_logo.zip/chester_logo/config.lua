Config = {}

-- LINK PNG (NO WEBP)
Config.ImageURL = "https://media.discordapp.net/attachments/1199531133877096569/1465756503674851461/2.png?ex=697a439e&is=6978f21e&hm=c9eeccfe9e0107641f9683af5269f5df4844af3796b1666f817d10074015fbcf&=&format=webp&quality=lossless"

-- Tamaño
Config.Width  = 400
Config.Height = 400

-- YA NO SE USA (el CSS manda)
Config.TopPx = 0

-- Opacidad suave (nunca 0)
Config.MinOpacity = 0.10
Config.MaxOpacity = 0.70

-- Velocidad del latido
Config.PulseSeconds = 1.5

Config.EnabledByDefault = true
Config.ToggleCommand = "overlay"
