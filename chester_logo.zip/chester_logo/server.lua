-- /overlayall on | off
RegisterCommand("overlayall", function(source, args)
  local v = (args[1] or ""):lower()
  if v ~= "on" and v ~= "off" then return end
  TriggerClientEvent("chester_overlay:setEnabled", -1, v == "on")
end, true)
