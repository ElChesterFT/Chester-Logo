local enabled = Config.EnabledByDefault
local nuiReady = false

local function clamp(x, a, b)
  x = tonumber(x) or a
  if x < a then return a end
  if x > b then return b end
  return x
end

local function pushAll()
  if not nuiReady then return end

  local cache = tostring(GetGameTimer())

  SendNUIMessage({
    type = "settings",
    url = Config.ImageURL .. "&v=" .. cache,
    width = Config.Width,
    height = Config.Height,
    minOpacity = clamp(Config.MinOpacity, 0.01, 1.0),
    maxOpacity = clamp(Config.MaxOpacity, 0.01, 1.0),
    pulseSeconds = math.max(0.1, Config.PulseSeconds)
  })

  SendNUIMessage({
    type = "toggle",
    enabled = enabled
  })
end

RegisterNUICallback("ready", function(_, cb)
  nuiReady = true
  pushAll()
  cb({})
end)

AddEventHandler("onClientResourceStart", function(res)
  if res ~= GetCurrentResourceName() then return end
  CreateThread(function()
    for _ = 1, 80 do
      if nuiReady then break end
      SendNUIMessage({ type = "ping" })
      Wait(200)
    end
    pushAll()
  end)
end)

RegisterCommand(Config.ToggleCommand, function()
  enabled = not enabled
  pushAll()
end, false)

RegisterNetEvent("chester_overlay:setEnabled", function(state)
  enabled = state and true or false
  pushAll()
end)
