fx_version 'cerulean'
game 'rdr3'
author 'TheChesters'
description 'Script de logo de servidor Parpadeante medio arriba de pantalla'
version '1.1.0'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'


ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css'
}

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'
